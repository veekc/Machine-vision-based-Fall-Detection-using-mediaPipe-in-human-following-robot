import numpy as np

def calculate_yield_stress(strain, stress):
    # Sort the strain and stress data in ascending order of strain
    sorted_indices = np.argsort(strain)
    sorted_strain = strain[sorted_indices]
    sorted_stress = stress[sorted_indices]

    # Calculate the 0.2% offset strain
    offset_strain = 0.002 * sorted_strain[-1]

    # Find the index where the stress is first greater than the offset stress
    index = np.argmax(sorted_stress > offset_strain)

    # Calculate the slope of the stress-strain curve using the linear regression method
    slope = (sorted_stress[index] - sorted_stress[index - 1]) / (sorted_strain[index] - sorted_strain[index - 1])

    # Calculate the 0.2% offset yield stress
    yield_stress = sorted_stress[index - 1] + slope * (offset_strain - sorted_strain[index - 1])

    return yield_stress

# Example usage
strain = np.array([0.001, 0.002, 0.003, 0.004, 0.005])  # Sample strain data
stress = np.array([100, 200, 300, 400, 500])  # Sample stress data

yield_stress = calculate_yield_stress(strain, stress)
print("0.2% Offset Yield Stress:", yield_stress)