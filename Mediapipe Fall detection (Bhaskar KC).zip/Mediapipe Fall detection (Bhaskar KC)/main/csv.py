import csv

def read_csv(filename):
    stress = []
    strain = []

    with open(filename, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip the header row if present

        for row in reader:
            stress.append(float(row[0]))
            strain.append(float(row[1]))

    return stress, strain

# Example usage
filename = 'data.csv'  # Replace with your CSV file path

stress, strain = read_csv(filename)

print("Stress:", stress)
print("Strain:", strain)